import EntradaTarefa from "../../EntradaTarefa/EntradaTarefa";
import "./TarefaPage.css";


function TarefaPage() {
  return ( <EntradaTarefa></EntradaTarefa>

  );
}

export default TarefaPage;



