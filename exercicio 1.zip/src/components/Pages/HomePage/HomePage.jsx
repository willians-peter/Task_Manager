import "./HomePage.css";

function HomePage() {
  return <p>Gerenciando tarefas desde ontem !</p>;
}

export default HomePage;
