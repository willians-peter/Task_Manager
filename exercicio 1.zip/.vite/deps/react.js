import {
  require_react
} from "./chunk-B2WE2YPZ.js";
export default require_react();
